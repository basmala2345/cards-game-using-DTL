const gameBoard = document.getElementById("gameBoard");
const movesCounter = document.getElementById("moves");

let cards = ["🍎","🍌","🍇","🍒","🍊","🍉","🍓","🥝"];
cards = [...cards, ...cards]; // مضاعفة الكروت

let moves = 0;
let flippedCards = [];
let matchedPairs = 0;

// ترتيب عشوائي
cards.sort(() => 0.5 - Math.random());

// إنشاء الكروت
cards.forEach(symbol => {
    const card = document.createElement("div");
    card.classList.add("card");
    card.dataset.symbol = symbol;
    card.addEventListener("click", flipCard);
    gameBoard.appendChild(card);
});

function flipCard() {
    if (this.classList.contains("flipped") || flippedCards.length === 2) return;

    this.textContent = this.dataset.symbol;
    this.classList.add("flipped");
    flippedCards.push(this);

    if (flippedCards.length === 2) {
        moves++;
        movesCounter.textContent = "عدد الحركات: " + moves;

        if (flippedCards[0].dataset.symbol === flippedCards[1].dataset.symbol) {
            matchedPairs++;
            flippedCards = [];
            if (matchedPairs === cards.length / 2) {
                setTimeout(() => alert("مبروك! خلصت اللعبة 🎉"), 500);
            }
        } else {
            setTimeout(() => {
                flippedCards.forEach(card => {
                    card.textContent = "";
                    card.classList.remove("flipped");
                });
                flippedCards = [];
            }, 1000);
        }
    }
}

from django.shortcuts import render
from datetime import datetime

def index(request):
    scores = [
        {"player": "بسملة", "moves": 18},
        {"player": "أحمد", "moves": 27},
        {"player": "سارة", "moves": 35},
    ]
    context = {
        "player_name": request.GET.get("name", "بسملة"),
        "moves": request.GET.get("moves", 0),
        "today": datetime.now(),
        "game_title": "memory game",
        "game_list": ["Memory", "Snake", "TicTacToe"],
        "scores": scores,
    }
    return render(request, "memory/index.html", context)
